package com.example.cinefile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinefileApplicationTests {

	@Test
	void contextLoads() {
	}

}
