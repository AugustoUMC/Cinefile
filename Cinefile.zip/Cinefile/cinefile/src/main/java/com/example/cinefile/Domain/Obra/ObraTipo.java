package com.example.cinefile.Domain.Obra;

public enum ObraTipo {
    FILME,
    SERIE
}
