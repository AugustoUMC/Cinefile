package com.example.cinefile.DTO;

import java.util.UUID;

public record LogVisualizacaoRequestDTO(Long obraId) {}
