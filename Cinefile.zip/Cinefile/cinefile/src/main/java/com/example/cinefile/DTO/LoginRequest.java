package com.example.cinefile.DTO;

public record LoginRequest(String username, String senha) {

}
