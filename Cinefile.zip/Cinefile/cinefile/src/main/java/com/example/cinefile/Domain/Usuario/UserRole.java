
package com.example.cinefile.Domain.Usuario;
public enum UserRole { ADMIN, USER }