ALTER TABLE usuario ADD active BOOLEAN;
UPDATE usuario SET active = true;